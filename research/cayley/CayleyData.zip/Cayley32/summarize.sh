#! /bin/bash

echo -n "PASS: "
fgrep PASS results-*.txt | wc -l
echo -n "WEAK: "
fgrep WEAK results-*.txt | wc -l
echo -n "FAIL: "
fgrep FAIL results-*.txt | wc -l
