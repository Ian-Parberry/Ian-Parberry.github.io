#! /bin/bash

for file in results*.txt
do
  echo -n "$file: "
  fgrep WEAK $file | wc -l
done
