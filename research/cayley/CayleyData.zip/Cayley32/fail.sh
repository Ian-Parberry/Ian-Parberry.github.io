#! /bin/bash

for file in results*.txt
do
  echo -n "$file: "
  fgrep FAIL $file | wc -l
done
