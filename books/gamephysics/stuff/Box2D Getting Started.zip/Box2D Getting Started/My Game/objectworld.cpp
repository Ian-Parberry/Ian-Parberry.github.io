///\file ObjectWorld.cpp
/// \brief Code for the object world CObjectWorld.

#include "objectworld.h"
#include "Timer.h"

extern CTimer g_cTimer;

CObjectWorld::CObjectWorld(){
  m_pObjectManager = new CObjectManager(720);
} //constructor

CObjectWorld::~CObjectWorld(){
  delete m_pObjectManager;
} //destructor

/// Create an object of a specified type, enter it into the object list, and return a pointer to it.
/// \param t Object type.
/// \return Pointer to the object created.

CGameObject* CObjectWorld::create(GameObjectType t){ // Create new object.
  return m_pObjectManager->create(t);
} //create

/// Set the Object World's width and height.
/// \param width Object World width.
/// \param height Object World height.

void CObjectWorld::SetWorldSize(float width, float height){
  m_fWidth = width; m_fHeight = height;
} //SetWorldSize

/// Get the Object World's width and height.
/// \param width Calling parameter will be set to Object World width.
/// \param height Calling parameter will be set to Object World height.

void CObjectWorld::GetWorldSize(float& width, float& height){
  width = m_fWidth; height = m_fHeight;
} //SetWorldSize

/// Clear objects.

void CObjectWorld::clear(){
  m_pObjectManager->clear();
} //clear

/// Draw everything in the Object World.
/// Draw the game objects using Painter's Algorithm.

void CObjectWorld::draw(){
  m_pObjectManager->draw(); //draw objects  
} //draw

/// Move objects.

void CObjectWorld::move(){
  m_pObjectManager->move(); //move objects
} //draw