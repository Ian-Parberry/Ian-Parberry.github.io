/// \file MyGame.cpp 
/// \brief Main file for your game.

/// \mainpage Box2D Getting Started
/// This code was written by Ian Parberry to accompany his book
/// "Introduction to Game Physics with Box2D", published by CRC Press in 2013.
///
/// This is a simple toy that helps you get started quickly with Box2D. The next
/// 3 chapters will drill down into Box2D more deeply, so don't be concerned if you
/// don't fully understand all of the code here. 
///
/// Each time you hit the space bar a new ball or book will fall out of the sky.
/// Hold the space bar down for autorepeat.

#include "gamedefines.h"
#include "SndList.h"

#include "Box2D\Box2D.h"
#include "RenderWorld.h"
#include "ObjectWorld.h"

//globals
char g_szGameName[256]; ///< Name of this game.

CTimer g_cTimer; ///< The game timer.
CSoundManager* g_pSoundManager; ///< The sound manager.

//Physics World. 
b2World g_b2dPhysicsWorld(b2Vec2(0, RW2PW(-100))); ///< Box2D Physics World.

//Render and Object Worlds
CRenderWorld g_cRenderWorld; ///< The Render World.
CObjectWorld g_cObjectWorld; ///< The Object World.


//prototypes for Windows functions
int DefaultWinMain(HINSTANCE, HINSTANCE, LPSTR, int);
LRESULT CALLBACK DefaultWindowProc(HWND, UINT, WPARAM, LPARAM);

//prototypes for functions in nonplayerobjects.cpp
void CreateWorldEdges();
void CreateBook(float x, float y);
void CreateBall(float x, float y);

/// Create all game objects.

void CreateObjects(){
  CreateWorldEdges(); //edges of screen
} //CreateObjects

/// Start the game.

void BeginGame(){ 
  g_cTimer.StartLevelTimer(); //starting level now     
  g_cObjectWorld.clear(); //clear old objects
  CreateObjects(); //create new objects
} //BeginGame

/// Initialize and start the game.

void InitGame(){
  //set up Render World
  g_cRenderWorld.Initialize(); //bails if it fails
  g_cRenderWorld.LoadImages(); //load images from xml file list

  //set up Object World
  int w, h;
  g_cRenderWorld.GetWorldSize(w, h);
  g_cObjectWorld.SetWorldSize((float)w, (float)h);

  //now start the game
  BeginGame();
} //InitGame

/// Shut down game and release resources.

void EndGame(){
  g_cRenderWorld.End();
} //EndGame

/// Render a frame of animation.

void RenderFrame(){
  if(g_cRenderWorld.BeginScene()){ //start up graphics pipeline
    g_cRenderWorld.DrawBackground(); //draw the background
    g_cObjectWorld.draw(); //draw the objects
    g_cRenderWorld.EndScene(); //shut down graphics pipeline
  } //if
} //RenderFrame

/// Process a frame of animation.
/// Called once a frame to animate game objects and take appropriate
/// action if the player has won or lost.

void ProcessFrame(){
  //stuff that gets done on every frame
  g_cTimer.beginframe(); //capture current time
  g_pSoundManager->beginframe(); //no double sounds
  g_cObjectWorld.move(); //move all objects
  RenderFrame(); //render a frame of animation
} //ProcessFrame

/// Keyboard handler.
/// Take the appropriate action when the user mashes a key on the keyboard.
///  \param k Virtual key code for the key pressed
///  \return TRUE if the game is to exit

BOOL KeyboardHandler(WPARAM k){ //keyboard handler
  static int nBookCount = 0; //number of books generated

  //pick a random-ish x, and a y above the top of the screen
  float x = (float)((4373*g_cTimer.time()/761)%100);
  float y = 77.0f;

  switch(k){ //keystroke
    case VK_ESCAPE:
      return TRUE;

    case VK_SPACE: 
      //create a ball at (x,y) in Physics World most of the time, but
      //make 32 of them books more or less random
      if((int)x%(nBookCount + 11) == 0 && nBookCount < 32){
        CreateBook(x, y); 
        nBookCount++;
      } //if
      else CreateBall(x, y);
      break;

    case VK_BACK: //clear
      g_cObjectWorld.clear(); 
      nBookCount = 0;
      break;
  } //switch

  return FALSE;
} //KeyboardHandler

// Windows functions.
// Dont mess with these unless you really know what you're doing.
// I've written default functions in the Engine library to take
// care of the boring details of Windows housekeeping.

/// Window procedure.
/// Handler for messages from the Windows API. Dont mess with these unless you really know what you're doing.
///  \param h window handle
///  \param m message code
///  \param w parameter for message 
///  \param l second parameter for message
///  \return 0 if message is handled

LRESULT CALLBACK WindowProc(HWND h, UINT m, WPARAM w, LPARAM l){
  return DefaultWindowProc(h, m, w, l);
} //WindowProc

/// Winmain.  
/// Main entry point for this application. Dont mess with these unless you really know what you're doing.
///  \param hI handle to the current instance of this application
///  \param hP unused
///  \param lpC unused 
///  \param nCS specifies how the window is to be shown
///  \return TRUE if application terminates correctly

int WINAPI WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR lpC, int nCS){                  
  return DefaultWinMain(hI, hP, lpC, nCS);
} //WinMain