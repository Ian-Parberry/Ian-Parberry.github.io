/// \file nonplayerobjects.cpp
/// \brief Code for the creation of nonplayer objects.
///
/// Creating things with a physics engine means a lot of tedious,
/// intricate initialization code. It makes sense to hide it in a file of
/// its own. It's not that it's so difficult, but that there is so much of it.
/// There are so many niggly little details to get right.

#include "gamedefines.h"
#include "Box2D\Box2D.h"
#include "ObjectWorld.h"

extern b2World g_b2dPhysicsWorld;
extern CObjectWorld g_cObjectWorld;

/// Create world edges in Physics World.
/// Place Box2D edge shapes in the Physics World in places that correspond to the
/// top, bottom, right, and left edges of the screen in Render World. The left and
/// right edges continue upwards for a distance. There is no top to the world.

void CreateWorldEdges(){
  float w, h;
  g_cObjectWorld.GetWorldSize(w, h);
  w = RW2PW(w);
  h = RW2PW(2.0f * h);

  const b2Vec2 vBottomLeft = b2Vec2(0, 0);
  const b2Vec2 vBottomRight = b2Vec2(w, 0);
  const b2Vec2 vTopLeft = b2Vec2(0, h);
  const b2Vec2 vTopRight = b2Vec2(w, h);

  //Box2D ground
  b2BodyDef bd;
	b2Body* edge = g_b2dPhysicsWorld.CreateBody(&bd);
  b2EdgeShape shape;
	shape.Set(vBottomLeft, vBottomRight);
	edge->CreateFixture(&shape, 0);

  //Box2D left edge of screen
  shape.Set(vBottomLeft, vTopLeft);
	edge->CreateFixture(&shape, 0);

  //Box2D right edge of screen
  shape.Set(vBottomRight, vTopRight);
	edge->CreateFixture(&shape, 0); 
} //CreateWorldEdges

/// Place a book in Physics World and Object World.
/// \param x Horizontal coordinate in Physics World units.
/// \param y  Vertical coordinate in Physics World units.

void CreateBook(float x, float y){ 

  //Object World
  CGameObject* pGameObject = g_cObjectWorld.create(BOOK_OBJECT);
  if(pGameObject == NULL)return; //bail and fail

  //Physics World
  b2BodyDef bd; 
	bd.type = b2_dynamicBody;
  bd.position.Set(x, y);

  //shape
  b2PolygonShape bookshape;
  bookshape.SetAsBox(RW2PW(27), RW2PW(32));

  //fixture
  b2FixtureDef bookfd;
	bookfd.shape = &bookshape;
	bookfd.density = 1.0f;
	bookfd.restitution = 0.3f;

  //body
  b2Body* pBook = g_b2dPhysicsWorld.CreateBody(&bd);
  pGameObject->SetPhysicsBody(pBook); //tell object world body about physics world body
  pBook->CreateFixture(&bookfd);
} //CreateBook

/// Place a ball in Physics World and Object World.
/// \param x Horizontal coordinate in Physics World units.
/// \param y  Vertical coordinate in Physics World units.

void CreateBall(float x, float y){ 

  //Object World
  CGameObject* pGameObject = g_cObjectWorld.create(BALL_OBJECT);
  if(pGameObject == NULL)return; //bail and fail

  //Physics World
  b2BodyDef bd;
	bd.type = b2_dynamicBody;
  bd.position.Set(x, y);

  //shape
  b2CircleShape ballshape;
	ballshape.m_radius = RW2PW(16);
	b2FixtureDef ballfd;

  //fixture
	ballfd.shape = &ballshape;
	ballfd.density = 0.8f;
	ballfd.restitution = 0.8f;

  //body
  b2Body* pBall = g_b2dPhysicsWorld.CreateBody(&bd);
  pGameObject->SetPhysicsBody(pBall); //tell object world body about physics world body
  pBall->CreateFixture(&ballfd);
} //CreateBall