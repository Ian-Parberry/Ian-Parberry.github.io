/// \file renderworld.cpp
/// \brief Code for the render world CRenderWorld.

#include "renderworld.h"

/// Load game images. Gets file list from gamesettings.xml.

void CRenderWorld::LoadImages(){ //load images
  LoadBackground(); 
  
  //Load sprite for each object
  Load(BALL_OBJECT, "ball"); 
  Load(BOOK_OBJECT, "book");
} //LoadImages