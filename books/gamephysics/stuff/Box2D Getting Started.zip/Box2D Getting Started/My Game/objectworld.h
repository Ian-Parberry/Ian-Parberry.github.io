/// \file objectworld.h
/// \brief Interface for the object world class CObjectWorld.

#pragma once

#include "ObjectManager.h"

/// \brief The object world.

class CObjectWorld{
  private:
    CObjectManager* m_pObjectManager; ///< Object manager
    float m_fWidth, m_fHeight; ///< Object world width and height.

  public:

    CObjectWorld(); //< Constructor.
    ~CObjectWorld(); //< Destructor.

    CGameObject* create(GameObjectType t); ///< Create new object.

    void SetWorldSize(float width, float height); ///< Set Object World dimensions.
    void GetWorldSize(float &width, float &height); ///< Get Object World dimensions.

    void clear(); //< Reset to initial conditions.
    void move(); //< Move all objects.
    void draw(); //< Draw all objects.
}; //CObjectWorld