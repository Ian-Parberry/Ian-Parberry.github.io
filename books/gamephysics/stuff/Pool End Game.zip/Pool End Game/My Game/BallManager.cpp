/// \file BallManager.cpp
/// \brief Code for the ball manager class CBallManager.

#include "BallManager.h"

#include "BallObject.h"
#include "renderworld.h"

#include "Sound.h"
#include "Sndlist.h"
#include "renderworld.h"

extern CRenderWorld g_cRenderWorld;
extern CSoundManager* g_pSoundManager;

CBallManager::CBallManager(int size): CObjectManager(size){
} //constructor

/// Create a new instance of a ball object.
/// \param object The type of the new ball.
/// \param position Initial position.

CGameObject* CBallManager::create(GameObjectType object, D3DXVECTOR2 position){
  if(m_nCount < m_nSize){ //if room, create object
    int i=0; while(m_pObjectList[i])i++; //find first free slot
    m_pObjectList[i] = new CBallObject(object, position); //conjure a ball
    m_nCount++; //one more object
    return m_pObjectList[i]; //success return
  } //if
  else return NULL; //failure return
} //create

void CBallManager::draw(){ 
  CBallObject* p;
  for(int i=0; i<m_nSize; i++){ //for each object slot
    p = (CBallObject*)m_pObjectList[i]; //handy object pointer
    if(p && !p->m_bInPocket){ //if there's an object there
      D3DXVECTOR2 v = p->m_vPosition;
      g_cRenderWorld.draw(p->m_nObjectType, v.x, v.y);
    } //if
  } //for
} //draw

BOOL CBallManager::BallBounce(CBallObject* b1, CBallObject* b2){
  float r = (float)(b1->m_nSize + b2->m_nSize)/2.0f;
  
  //calculate relative velocity v, normalized version vhat
  D3DXVECTOR2 v = b2->m_vVelocity - b1->m_vVelocity;
  D3DXVECTOR2 vhat;
  D3DXVec2Normalize(&vhat, &v);
  
  //calculate relative displacement and distance along normal to common tangent
  D3DXVECTOR2 c = b2->m_vPosition - b1->m_vPosition; //relative displacement along normal to tangent
  D3DXVECTOR2 n; D3DXVec2Normalize(&n, &c); //normal to tangent
  float cdotvhat = D3DXVec2Dot(&c, &vhat); //relative distance along normal to tangent

  //calculate d2, the distance moved back by ball2
  float d2;
  float discriminant = cdotvhat*cdotvhat - D3DXVec2LengthSq(&c) + r*r;
  if(discriminant >= 0.0f)
    d2 = cdotvhat + sqrt(discriminant);
  else return FALSE; //fail

  //calculate d1, the distance moved back by ball1
  float vf = D3DXVec2Length(&b2->m_vVelocity) > 0.0f? //relative velocity factor
    D3DXVec2Length(&b1->m_vVelocity)/D3DXVec2Length(&b2->m_vVelocity): 0.0f;
  float d1 = d2 * vf;

  //move balls back to point of impact 
  D3DXVECTOR2 v1hat, v2hat;
  D3DXVec2Normalize(&v1hat, &b1->m_vVelocity);
  D3DXVec2Normalize(&v2hat, &b2->m_vVelocity);
  b1->m_vPosition -= d1 * v1hat; 
  b2->m_vPosition -= d2 * v2hat; 

  //ball-to-ball reflection
  D3DXVECTOR2 vDiff = b1->m_vVelocity - b2->m_vVelocity;
  vDiff = D3DXVec2Dot(&vDiff, &n) * n;
  b1->m_vVelocity -= vDiff;
  b2->m_vVelocity += vDiff;


  //move by the correct amount in direction of bounce
  //must recompute v1hat and v2hat because velocities have changed
  D3DXVec2Normalize(&v1hat, &b1->m_vVelocity);
  D3DXVec2Normalize(&v2hat, &b2->m_vVelocity);
  b1->m_vPosition +=  d1 * v1hat;
  b2->m_vPosition +=  d2 * v2hat;

  return TRUE;
} //BallBounce


BOOL CBallManager::CollisionPoint(CBallObject* b1, CBallObject* b2, D3DXVECTOR2& v, D3DXVECTOR2& point){  
  float r = (b1->m_nSize + b2->m_nSize)/2.0f;
  
  D3DXVECTOR2 p1, v1, p2;
  p1 = b1->m_vPosition;
  p2 = b2->m_vPosition;

  v1 = v;

  D3DXVECTOR2  n, v1hat;
  float cdotvhat, d, m;
  
  D3DXVec2Normalize(&v1hat, &v1);
 
  D3DXVECTOR2 c = p2 - p1; //vector between centers
  cdotvhat = D3DXVec2Dot(&c, &v1hat); //c dot vhat, relative distance along normal to tangent
  D3DXVec2Normalize(&n, &c); //normal to tangent
  m = D3DXVec2Dot(&v1, &n); //relative velocity along normal to tangent

  float discriminant = cdotvhat*cdotvhat - D3DXVec2LengthSq(&c) + r*r;
  if(discriminant >= 0.0f)
    d = -cdotvhat + sqrt(discriminant);
  else return FALSE;

  point = p1 - d * v1hat;
  v = p2 - point;

  return TRUE;
} //CollisionPoint

/// Collision detection and response.
/// This function relies on the game engine code for collision response,
/// and merely adds an appropriate sound for ball collision.
/// \param i Handle response for colisions with ball at index i in the object list.
/// \return TRUE iff it collides with some other object.

void CBallManager::CollisionResponse(int i){
  CBallObject* b1 = (CBallObject*)m_pObjectList[i];
  if(!b1)return;
  if(!b1->m_bCanCollide)return;

  //Compare against only higher-indexed objects to avoid processing each collision twice.
  for(int j=i+1; j<m_nSize; j++){
    CBallObject* b2 = (CBallObject*)m_pObjectList[j];
    if(b2 && b2->m_bCanCollide){ //if object j exists   
      D3DXVECTOR2 vDeltaS = b1->m_vPosition - b2->m_vPosition; //position difference
      float distance =  (b1->m_nSize +  b2->m_nSize)/2.0f; //distance
      if(D3DXVec2LengthSq(&vDeltaS) < distance*distance &&
      !(b1->m_bAtRest && b2->m_bAtRest)){ //if close enough, then we collide
        g_pSoundManager->play(BALLCLICK_SOUND); //play appropriate sound
        b1->m_bAtRest = b2->m_bAtRest = FALSE; //will get corrected in next frame if wrong
        BallBounce(b1, b2);
      } //if close enough
    } //if object exists
  } //for all objects
} //CollisionResponse

/// Perform collision response for all objects. This function basically
/// consists of a for-loop on i calling CollisionResponse(i)

void CBallManager::CollisionResponse(){
  for(int i=0; i < m_nSize; i++) //for each object
    CollisionResponse(i); //collisions with everything else
} //CollisionResponse