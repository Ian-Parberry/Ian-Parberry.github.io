/// \file BallManager.h
/// \brief Interface for the ball manager class CBallManager.

#pragma once

#include "objectmanager.h"
#include "ballobject.h"

/// \brief The ball manager.
///
/// The ball manager is responsible for managing the pool balls.

class CBallManager: public CObjectManager{
  private:
    void CollisionResponse(int i); ///< Collision detection and response for an object.
    BOOL BallBounce(CBallObject* b1, CBallObject* b2);
  public:
    CBallManager(int size); ///< Constructor.
    CGameObject* create(GameObjectType object, D3DXVECTOR2 position); ///< Create a ball object.
    void draw();
    void CollisionResponse(); ///< Collision detection and response.
    BOOL CollisionPoint(CBallObject* b1, CBallObject* b2, D3DXVECTOR2& v, D3DXVECTOR2& point);
}; //CBallManager