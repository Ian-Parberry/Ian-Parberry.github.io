/// \file object.h
/// \brief Interface for the game object class CGameObject.

#pragma once

#include "gamedefines.h"

/// \brief The game object.
///
/// Game objects are responsible for remembering information about themselves,
/// in particular, their representations in Render World and Physics World.

class CGameObject{ //class for a game object

  //CGameObject has a lot of friends
  friend class CObjectManager; //because the Object World manages objects
  friend class CBallManager;
  friend class CObjectWorld; //...and the Object World too, obviously
  friend class CRenderWorld; //because Render World need to draw them

  protected:
    GameObjectType m_nObjectType; ///< Object type.
    D3DXVECTOR2 m_vPosition; ///< Current position.
    D3DXVECTOR2 m_vVelocity; ///< Current velocity.
    int m_nLastMoveTime; ///< Last time moved.
    BOOL m_bAtRest; ///< Whether object is at rest.
    int m_nFrictionTime; ///< Timer for applying friction.

  public:
    CGameObject(GameObjectType objecttype); ///< Constructor.
    virtual void move(); ///< Move yourself, raus raus raus!
}; //CGameObject