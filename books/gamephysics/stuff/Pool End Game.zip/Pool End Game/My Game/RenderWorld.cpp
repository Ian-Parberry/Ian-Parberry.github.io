/// \file renderworld.cpp
/// \brief Code for the render world class CRenderWorld.

#include "renderworld.h"

/// Load game images. Gets file list from gamesettings.xml.

void CRenderWorld::LoadImages(){ //load images
  LoadBackground(); 
  
  //Load sprite for each object
  Load(ARROW_OBJECT, "arrow"); 
  Load(CUEBALL_OBJECT, "cueball"); 
  Load(EIGHTBALL_OBJECT, "eightball"); 
} //LoadImages
 
/// Tell the player whether they've won or lost by plastering a text banner across the screen.
/// \param state The game state, which tells whether the player has won or lost.

void CRenderWorld::DrawWinLoseMessage(GameStateType state){
  switch(state){
    case WON_GAMESTATE:
      TextWrite("You Win!");
      break;
    case LOST_GAMESTATE:
      TextWrite("Loser!");
      break;
  } //switch
} //DrawWinLoseMessage