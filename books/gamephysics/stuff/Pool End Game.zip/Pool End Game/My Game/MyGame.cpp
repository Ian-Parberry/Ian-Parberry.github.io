/// \file MyGame.cpp 
/// \brief Main file for your game.

/// \mainpage Pool End Game
/// This code was written by Ian Parberry to accompany his book
/// "Introduction to Game Physics with Box2D", published by CRC Press in 2013.
/// 
/// This is the Pool End Game, a simple Windows application that uses
/// DirectX 9 for rendering and hand-written code for the physics.
/// The code uses ball-to-wall and ball-to-ball collision detection
/// and response from Chapter 2.
/// The aim is to sink the 8-ball while not sinking the cue-ball. 
///
/// Use the up and down arrow keys to adjust the initial position of the
/// cue-ball, the left and right arrow keys to adjust the cue-ball's direction 
/// (indicated by an arrow on the screen, and the space key to fire the ball. The
/// space bar also restarts the game after you've sunk a ball. ESC exits the game.

#include "debug.h"

#include "gamedefines.h"
#include "SndList.h"

#include "RenderWorld.h"
#include "ObjectWorld.h"

extern int g_nScreenHeight;

//globals
char g_szGameName[256]; ///< Name of this game.
GameStateType g_nGameState; ///< Current game state.

CTimer g_cTimer; ///< The game timer.
CSoundManager* g_pSoundManager; ///< The sound manager.

//Render and Object Worlds
CRenderWorld g_cRenderWorld; ///< The Render World.
CObjectWorld g_cObjectWorld; ///< The Object World.

//prototypes for Windows functions
int DefaultWinMain(HINSTANCE, HINSTANCE, LPSTR, int);
LRESULT CALLBACK DefaultWindowProc(HWND, UINT, WPARAM, LPARAM);

/// Create all game objects.

void CreateObjects(){
  D3DXVECTOR2 v; //object position

  //create 8 ball
  v.x = 750.0f; v.y = (float)g_nScreenHeight/2.0f;
  g_cObjectWorld.create(EIGHTBALL_OBJECT, v);
  
  //create cue ball
  v.x = 295.0f; v.y = (float)g_nScreenHeight/2.0f;
  g_cObjectWorld.create(CUEBALL_OBJECT, v);
  g_cObjectWorld.ResetImpulseVector();
} //CreateObjects

/// Start the game.

void BeginGame(){ 
  g_nGameState = INITIAL_GAMESTATE; //playing state
  g_cTimer.StartLevelTimer(); //starting level now     
  g_cObjectWorld.clear(); //clear old objects
  CreateObjects(); //create new objects

  DEBUGPRINTF("Begin game at time %d\n", g_cTimer.time());
} //BeginGame

/// Initialize and start the game.

void InitGame(){
  //set up Render World
  g_cRenderWorld.Initialize(); //bails if it fails
  g_cRenderWorld.LoadImages(); //load images from xml file list

  //now start the game
  BeginGame();
} //InitGame

/// Shut down game and release resources.

void EndGame(){
  g_cRenderWorld.End();
} //EndGame

/// Render a frame of animation.

void RenderFrame(){
  if(g_cRenderWorld.BeginScene()){ //start up graphics pipeline
    g_cRenderWorld.DrawBackground(); //draw the background
    g_cObjectWorld.draw(); //draw the objects
    g_cRenderWorld.DrawWinLoseMessage(g_nGameState);
    g_cRenderWorld.EndScene(); //shut down graphics pipeline
  } //if
} //RenderFrame

/// Process a frame of animation.
/// Called once a frame to animate game objects and take appropriate
/// action if the player has won or lost.

void ProcessFrame(){
  //stuff that gets done on every frame
  g_cTimer.beginframe(); //capture current time
  g_pSoundManager->beginframe(); //no double sounds
  g_cObjectWorld.move(); //move all objects
  RenderFrame(); //render a frame of animation

  //change game state to set up next shot, if necessary
  if(g_cObjectWorld.CueBallDown())
    g_nGameState = LOST_GAMESTATE;
  else if(g_cObjectWorld.BallDown()) //a non-cue-ball is down, must be the 8-ball
    g_nGameState = WON_GAMESTATE; 
  else if(g_nGameState == BALLSMOVING_GAMESTATE && 
  !g_cObjectWorld.BallDown() &&
  g_cObjectWorld.AllBallsStopped()){ //shoot again
    g_nGameState = SETTINGUPSHOT_GAMESTATE;
    g_cObjectWorld.ResetImpulseVector();
  }
} //ProcessFrame

/// Keyboard handler.
/// Take the appropriate action when the user mashes a key on the keyboard.
///  \param k Virtual key code for the key pressed
///  \return TRUE if the game is to exit

BOOL KeyboardHandler(WPARAM k){ //keyboard handler

  const float MOVEDELTA = 5.0f; ///< Small change in position.
  const float ANGLEDELTA = 0.01f; ///< Small change in angle.

  switch(k){
    case VK_ESCAPE: return TRUE; //quit

    case VK_UP: 
      if(g_nGameState == INITIAL_GAMESTATE){     
        g_cObjectWorld.AdjustCueBall(MOVEDELTA); 
        g_cObjectWorld.ResetImpulseVector();
      } //if
    break;

    case VK_DOWN:  
      if(g_nGameState == INITIAL_GAMESTATE){       
        g_cObjectWorld.AdjustCueBall(-MOVEDELTA); 
        g_cObjectWorld.ResetImpulseVector();
      } //if
      break;

    case VK_LEFT:
      if(g_nGameState == SETTINGUPSHOT_GAMESTATE || g_nGameState == INITIAL_GAMESTATE)
        g_cObjectWorld.AdjustImpulseVector(ANGLEDELTA);
      break;

    case VK_RIGHT:
      if(g_nGameState == SETTINGUPSHOT_GAMESTATE || g_nGameState == INITIAL_GAMESTATE)
        g_cObjectWorld.AdjustImpulseVector(-ANGLEDELTA);
      break;

    case VK_SPACE:     
      if((g_nGameState == WON_GAMESTATE || g_nGameState == LOST_GAMESTATE)
        && g_cObjectWorld.AllBallsStopped())BeginGame();
      else if(g_nGameState == SETTINGUPSHOT_GAMESTATE || g_nGameState == INITIAL_GAMESTATE){
        g_nGameState = BALLSMOVING_GAMESTATE;
        g_cObjectWorld.shoot();
        g_pSoundManager->play(CUE_SOUND);
      } //else if
      break;
  } //switch

  return FALSE;
} //KeyboardHandler

// Windows functions.
// Dont mess with these unless you really know what you're doing.
// I've written default functions in the Engine library to take
// care of the boring details of Windows housekeeping.

/// Window procedure.
/// Handler for messages from the Windows API. Dont mess with these unless you really know what you're doing.
///  \param h window handle
///  \param m message code
///  \param w parameter for message 
///  \param l second parameter for message
///  \return 0 if message is handled

LRESULT CALLBACK WindowProc(HWND h, UINT m, WPARAM w, LPARAM l){
  return DefaultWindowProc(h, m, w, l);
} //WindowProc

/// Winmain.  
/// Main entry point for this application. Dont mess with these unless you really know what you're doing.
///  \param hI handle to the current instance of this application
///  \param hP unused
///  \param lpC unused 
///  \param nCS specifies how the window is to be shown
///  \return TRUE if application terminates correctly

int WINAPI WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR lpC, int nCS){                  
  return DefaultWinMain(hI, hP, lpC, nCS);
} //WinMain