/// \file ballobject.cpp
/// \brief Code for the game object class CBallObject.

#include "ballobject.h"

#include "Sound.h"
#include "sndlist.h"

extern int g_nScreenWidth; 
extern int g_nScreenHeight; 
extern CSoundManager* g_pSoundManager; 

CBallObject::CBallObject(GameObjectType object, D3DXVECTOR2 position): //constructor
CGameObject(object){ 
  m_nSize = 50; // Total kludge
  m_vPosition = position;
  m_vVelocity = D3DXVECTOR2(0, 0);
  m_bAtRest = TRUE;
  m_bInPocket = FALSE;
  m_bCanCollide = TRUE;
} //constructor

/// Check for collision with a pocket.
/// Collision and response for ball-in-pocket. Checks for a collision, and
/// does the necessary housework for disabling a ball if it is in a pocket.
/// \return TRUE if ball is in a pocket.

BOOL CBallObject::PocketCollision(){ 
  const float HMARGIN = 103.0f; //horizontal margin, kludged for side rails
  const float CMARGIN =10.0f; //horizontal margin for center pockets
  const float VMARGIN = 95.0f; //vertical margin, kludged for top and bottom rails
  BOOL bVertical = m_vPosition.y < VMARGIN || m_vPosition.y > g_nScreenHeight - VMARGIN;
  if(m_vPosition.x < HMARGIN) //left corner pockets
    m_bInPocket = bVertical;
  else if(m_vPosition.x > g_nScreenWidth - HMARGIN) //right corner pockets
    m_bInPocket = bVertical;
  else if(fabs(m_vPosition.x-g_nScreenWidth/2) < CMARGIN) //center pockets
    m_bInPocket = bVertical;
  if(m_bInPocket){ 
    m_bAtRest = TRUE; 
    m_bCanCollide = FALSE;
  } //if

  return m_bInPocket;
} //PocketCollision

/// Check for collision with a rail.
/// Collision and response for ball hitting a rail. Checks for a collision, and
/// does the necessary housework for reflecting a ball if it hits a rail. Function
/// backs off the ball so that it does not appear to overlap the rail.
/// \return TRUE if ball is in a pocket.

BOOL CBallObject::RailCollision(){ 
  const float radius = m_nSize/2.0f; //ball radius

  //rail positions hard-coded from image
  const float TOP = g_nScreenHeight - 64.0f - radius;
  const float BOTTOM = 64.0f + radius;
  const float LEFT = 78.0f + radius;
  const float RIGHT = g_nScreenWidth - 72.0f - radius;

  const float fRailRestitution = 0.75f; //how bouncy the rails are
  BOOL result=FALSE; //whether we hit

  if(m_vPosition.x < LEFT){ //left rail
    m_vPosition.x = LEFT;
    if(fabs(m_vVelocity.x) > 0.0f){ //could fail if ball moved by hand
      m_vPosition.y += (LEFT - m_vPosition.x) *  m_vVelocity.y / m_vVelocity.x;
      m_vVelocity.x = -fRailRestitution * m_vVelocity.x; 
    } //if
    result = TRUE;
  } //if left rail

  else if(m_vPosition.x > RIGHT){ //right rail 
    m_vPosition.x = RIGHT; 
    if(fabs(m_vVelocity.x) > 0.0f){ //could fail if ball moved by hand
      m_vPosition.y += (m_vPosition.x - RIGHT) *  m_vVelocity.y / m_vVelocity.x;
      m_vVelocity.x = -fRailRestitution * m_vVelocity.x; 
    } //if
    result = TRUE;
  } //if right rail
  
  if(m_vPosition.y < BOTTOM){ //bottom rail
    m_vPosition.y = BOTTOM; ; 
    if(fabs(m_vVelocity.y) > 0.0f){ //could fail if ball moved by hand
      m_vPosition.x += (BOTTOM - m_vPosition.y) * m_vVelocity.x / m_vVelocity.y;
      m_vVelocity.y = -fRailRestitution * m_vVelocity.y; 
    } //if
    result = TRUE;
  } //if bottom rail
  
  else if(m_vPosition.y > TOP){ //top rail
    m_vPosition.y = TOP; 
    if(fabs(m_vVelocity.y) > 0.0f){ //could fail if ball moved by hand
      m_vPosition.x -= (m_vPosition.y - TOP) * m_vVelocity.x / m_vVelocity.y;
      m_vVelocity.y = -fRailRestitution * m_vVelocity.y; 
    } //if
    result = TRUE;
  } //if top rail

  return result;
} //RailCollision

/// Move ball.
/// Move the ball, apply collision and response with pockets and rails,
/// playing the appropriate sound if necessary.

void CBallObject::move(){ //move object
  if(m_bInPocket)return; //bail if in pocket

  CGameObject::move(); //change position

  //sounds
  if(PocketCollision()) //pocket collision
    g_pSoundManager->play(POCKET_SOUND);
  if(RailCollision()) //rail collision
    g_pSoundManager->play(THUMP_SOUND);
} //move

/// Deliver an impulse to the object, given the angle and magnitude.
/// \param angle Angle at which the impulse is to be applied.
/// \param magnitude Magnitude of the impulse to apply.

void CBallObject::DeliverImpulse(float angle, float magnitude){ 
  m_bAtRest = FALSE;
  m_vVelocity = magnitude * D3DXVECTOR2(cos(angle), sin(angle));
} //DeliverImpulse

/// Change velocity to a new value. This is mainly used in collision response.
/// \param velocity New velocity vector.

void CBallObject::SetVelocity(D3DXVECTOR2 velocity){ //change object velocity
  m_bAtRest = FALSE; //moving... will be reset in next frame if wrong
  m_vVelocity = velocity; //new velocity
} //SetVelocity