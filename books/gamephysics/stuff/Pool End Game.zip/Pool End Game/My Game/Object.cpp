/// \file object.cpp
/// \brief Code for the game object class CGameObject.

#include "object.h"

#include "Timer.h"

extern CTimer g_cTimer;

/// Constructor for a game object.
/// \param objecttype Object type.

CGameObject::CGameObject(GameObjectType objecttype){ //constructor
  m_nObjectType = objecttype; 
  m_vPosition = m_vVelocity = D3DXVECTOR2(0, 0);
  m_nLastMoveTime = m_nFrictionTime = g_cTimer.time();
} //constructor

/// Move in proportion to velocity vector and time since last move, and apply
/// a small amount of friction to reduce the velocity.

void CGameObject:: move(){
  const float SCALE = 20.0f; //to scale back motion
  int time=g_cTimer.time(); //current time
  int dt = time - m_nLastMoveTime; //time since last move
  m_vPosition += m_vVelocity * (float)dt / SCALE; //move
  m_nLastMoveTime = time; //last time moved is now

  if(g_cTimer.elapsed(m_nFrictionTime, 100)) //friction
    m_vVelocity *= 0.95f; //kludge the amount of friction

  if(D3DXVec2LengthSq(&m_vVelocity) < 0.5f){ //if moving too slowly
    m_vVelocity = D3DXVECTOR2(0, 0); //stop
    m_bAtRest = TRUE; //really and truly not moving
  } //if
} //move