/// \file ObjectManager.cpp
/// \brief Code for the object manager class CObjectManager.

#include "ObjectManager.h"

#include "renderworld.h"

extern CRenderWorld g_cRenderWorld;

CObjectManager::CObjectManager(int size){ //constructor 
  m_pObjectList = new CGameObject* [size];
  m_nCount = 0; //no objects
  for(int i=0; i<size; i++) //null our object list
    m_pObjectList[i] = NULL;
  m_nSize = size; //this is the size
} //constructor

CObjectManager::~CObjectManager(){ //destructor
  for(int i=0; i<m_nSize; i++) //for each object
    delete m_pObjectList[i]; //delete it
  delete [] m_pObjectList;
} //destructor

/// Create a new instance of a game object.
/// \param objecttype The type of the new object

CGameObject* CObjectManager::create(GameObjectType objecttype){
  if(m_nCount < m_nSize){ //if room, create object
    int i=0; while(m_pObjectList[i])i++; //find first free slot
    m_pObjectList[i] = new CGameObject(objecttype);
    m_nCount++; //one more object
    return m_pObjectList[i];
  } //if
  else return NULL;
} //create

/// Move the game objects.

void CObjectManager::move(){ 
  CGameObject* p; //an object
  GameObjectType t; //its type
  for(int i=0; i<m_nSize; i++){ //for each object slot
    p = m_pObjectList[i]; //handy object pointer
    if(p){
      t = p->m_nObjectType; //get its type
      if(t == CUEBALL_OBJECT || t == EIGHTBALL_OBJECT) //if its a ball
        p->move(); //make it move
    } //if
  } //for
} //move

/// Ask the Render World to draw all of the game objects.

void CObjectManager::draw(){ 
  CGameObject* p;
  for(int i=0; i<m_nSize; i++){ //for each object slot
    p = m_pObjectList[i]; //handy object pointer
    if(p){ //if there's an object there
      D3DXVECTOR2 v = p->m_vPosition;
      g_cRenderWorld.draw(p->m_nObjectType, v.x, v.y);
    } //if
  } //for
} //draw

/// Clear out all game objects from the object list. 

void CObjectManager::clear(){ 
  m_nCount = 0; //no objects
  for(int i=0; i<m_nSize; i++){ //for each object
    delete m_pObjectList[i]; //delete it
    m_pObjectList[i] = NULL; //safe delete
  } //for
} //clear