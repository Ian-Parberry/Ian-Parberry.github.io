/// \file ObjectWorld.cpp
/// \brief Code for the object world class CObjectWorld.

#include "objectworld.h"
#include "Timer.h"
#include "RenderWorld.h"

extern CTimer g_cTimer;
extern CRenderWorld g_cRenderWorld;

CObjectWorld::CObjectWorld(){
  m_pBallManager = new CBallManager(16);
  m_fCueBallImpulseAngle = 0.0f;
  m_pCueBallObject = m_p8BallObject = NULL;
  m_bDrawImpulseVector = TRUE;
} //constructor

/// Create an object in the Object World.
/// \param t Object type.
/// \param position Initial position.
/// \return Pointer to the object created.

void CObjectWorld::create(GameObjectType t, D3DXVECTOR2 position){ // Create new object.
  CGameObject* b;
  b = m_pBallManager->create(t, position);
  if(t == CUEBALL_OBJECT)
    m_pCueBallObject = (CBallObject*)b;
  else if(t == EIGHTBALL_OBJECT)
    m_p8BallObject = (CBallObject*)b;
} //create

/// Clear objects.

void CObjectWorld::clear(){
  m_pBallManager->clear();
} //clear

/// Draw everything in the Object World.
/// Draw the impulse vector, then the game objects.

void CObjectWorld::draw(){
  if(m_pCueBallObject){ //draw the impulse vector on cueball
    D3DXVECTOR2 p = m_pCueBallObject->m_vPosition;
    if(m_bDrawImpulseVector){
      g_cRenderWorld.draw(ARROW_OBJECT, p.x, p.y, m_fCueBallImpulseAngle);
      D3DXVECTOR2 v = D3DXVECTOR2(cos(m_fCueBallImpulseAngle), sin(m_fCueBallImpulseAngle));
    } //if m_bDrawImpulseVector
  } //if m_pCueBallObject

  m_pBallManager->draw(); //draw the balls next
} //draw

/// Move objects.

void CObjectWorld::move(){
  m_pBallManager->move(); //move objects
  m_pBallManager->CollisionResponse(); //handle collisions between objects
} //move

/// Make the impulse vector point from the center of the cue-ball object
/// to the center of the 8-ball object.

void CObjectWorld::ResetImpulseVector(){
  m_bDrawImpulseVector = TRUE;
  D3DXVECTOR2 v = m_p8BallObject->m_vPosition - m_pCueBallObject->m_vPosition; //difference in positions
  m_fCueBallImpulseAngle = atan2(v.y, v.x);
} //ResetImpulseVector

/// Adjust the cue ball up or down.
/// \param amount Amount to move by.

void CObjectWorld::AdjustImpulseVector(float amount){
  m_fCueBallImpulseAngle += amount;
} //AdjustImpulseVector

/// Adjust the cue ball up or down.
/// \param amount Amount to move by.

void CObjectWorld::AdjustCueBall(float amount){
  if(m_pCueBallObject){ //safety
    m_pCueBallObject->m_vPosition.y += amount; //move it vertically
    m_pCueBallObject->RailCollision(); //check for collision with rails
  } //if
} //AdjustCueBall

void CObjectWorld::shoot(){
  m_bDrawImpulseVector = FALSE;
  if(m_pCueBallObject) //safety
    m_pCueBallObject->DeliverImpulse(m_fCueBallImpulseAngle, 30.0f);
} //shoot

/// Check whether the cue-ball or the 8-ball is in a pocket.
/// \return TRUE If one of the balls is in a pocket.

BOOL CObjectWorld::BallDown(){
  return m_pCueBallObject->m_bInPocket || 
    m_p8BallObject->m_bInPocket;
} //BallDown

/// Check whether the cue-ball is in a pocket.
/// \return TRUE If the cue-ball is in a pocket.

BOOL CObjectWorld::CueBallDown(){
  return m_pCueBallObject->m_bInPocket;
} //CueBallDown

/// Check whether both the cue-ball and the 8-ball have stopped moving.
/// \return TRUE If both balls have stopped moving.

BOOL CObjectWorld::AllBallsStopped(){
  return m_pCueBallObject->m_bAtRest &&
    m_p8BallObject->m_bAtRest;
} //AllBallsStopped