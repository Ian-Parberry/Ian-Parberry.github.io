/// \file gamedefines.h
/// \brief Game defines.

#pragma once

#include "defines.h"

/// \brief Object type.
///
/// Types of object that can appear in the game. 

enum GameObjectType{
  ARROW_OBJECT, CUEBALL_OBJECT, EIGHTBALL_OBJECT
}; //GameObjectType

/// State of game play, including whether the player has won or lost.

enum GameStateType{
  INITIAL_GAMESTATE, BALLSMOVING_GAMESTATE,  SETTINGUPSHOT_GAMESTATE, WON_GAMESTATE, LOST_GAMESTATE
}; //GameStateType