/// \file objectworld.h
/// \brief Interface for the object world class CObjectWorld.

#pragma once

#include "BallManager.h"
#include "BallObject.h"

/// \brief The object world.

class CObjectWorld{

  private:
    CBallManager* m_pBallManager; ///< Object manager.

    float m_fCueBallImpulseAngle; ///< Cue ball impulse angle.
    float m_f8BallImpulseAngle; ///< 8 ball impulse angle.
    CBallObject* m_pCueBallObject; ///< Cue ball object pointer.
    CBallObject* m_p8BallObject; ///< 8 ball object pointer.
    BOOL m_bDrawImpulseVector; ///< Whether to draw the impulse vector.

  public:

    CObjectWorld(); //< Constructor.

    void create(GameObjectType t, D3DXVECTOR2 position); ///< Create new object.

    void clear(); //< Reset to initial conditions.
    void move(); //< Move all objects.
    void draw(); //< Draw all objects.
    
    void ResetImpulseVector(); ///< Reset the Impulse Vector.
    void AdjustImpulseVector(float amount); ///< Adjust the Impulse Vector.
    void AdjustCueBall(float amount); ///< Move cue-ball up or down.
    void shoot(); ///< Shoot the cue ball.
    BOOL BallDown(); ///< Is a ball down in a pocket?
    BOOL CueBallDown(); ///< Is the cue ball down in a pocket?
    BOOL AllBallsStopped(); ///< Have all balls stopped moving?
}; //CObjectWorld