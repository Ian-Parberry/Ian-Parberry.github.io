/// \file ballobject.h
/// \brief Interface for the game object class CBallObject.

#pragma once

#include "object.h"
#include "gamedefines.h"

/// \brief The ball object. 

class CBallObject: public CGameObject{ //class for a ball object
  friend class CBallManager;
  friend class CObjectWorld;
  friend class CObjectManager;

  private:
    int m_nSize; ///< Object size.
    BOOL m_bInPocket; ///< Whether ball is currently in a pocket.
    BOOL m_bCanCollide; ///< Whether ball can collide.

    BOOL PocketCollision(); ///< Collision detection and response for pockets.
    BOOL RailCollision(); ///< Collision detection and response for rails.
    void SetVelocity(D3DXVECTOR2 velocity); ///< Set velocity.

  public:
    CBallObject(GameObjectType object, D3DXVECTOR2 position); ///< Constructor.
    void move(); ///< Change position depending on time and velocity.
    void DeliverImpulse(float angle, float magnitude); ///< Deliver an impulse.
}; //CBallObject