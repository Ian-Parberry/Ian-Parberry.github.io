#include "AbstractList.h"

template <class thing>
CAbstractList<thing>::CAbstractList(int size){ //constructor 
  m_pObjectList = new <thing>* [size];
  m_nCount = 0; //no objects
  for(int i=0; i<size; i++) //null our object list
    m_pObjectList[i] = NULL;
  m_nSize = size; //this is the size
} //constructor

template <class thing>
CAbstractList<thing>::~CAbstractList(){ //destructor
  for(int i=0; i<m_nSize; i++) //for each object
    delete m_pObjectList[i]; //delete it
  delete [] m_pObjectList;
} //destructor

template <class thing>
BOOL CAbstractList<thing>::Insert(thing* newthing){
  if(m_nCount < m_nSize){ //if room
    int i=0; while(m_pObjectList[i])i++; //find first free slot
    m_pObjectList[i] = newthing;
    m_nCount++; //one more object
    return TRUE;
  } //if
  else return FALSE;
} //Insert

template <class thing>
void CAbstractList<thing>::clear(){ 
  m_nCount = 0; //no objects
  for(int i=0; i<m_nSize; i++){ //for each object
    delete m_pObjectList[i]; //delete it
    m_pObjectList[i] = NULL; //safe delete
  } //for
} //Clear