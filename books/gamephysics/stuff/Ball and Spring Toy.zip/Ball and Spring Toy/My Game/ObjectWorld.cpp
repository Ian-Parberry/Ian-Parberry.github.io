/// \file ObjectWorld.cpp
/// \brief Code for the object world clss CObjectWorld.

#include "objectworld.h"
#include "RenderWorld.h"
#include "Body.h"
#include "debug.h"

extern CRenderWorld g_cRenderWorld;
extern int g_nScreenWidth;
extern int g_nScreenHeight;
extern CTimer g_cTimer;

extern BodyType g_nCurrentBody; 
extern int g_nIterations; 

CObjectWorld::CObjectWorld(){
  m_pParticleManager = NULL;
  m_pSpringManager = NULL;
  clear();
} //constructor

/// Clear objects.

void CObjectWorld::clear(){
  delete m_pParticleManager;
  m_pParticleManager = new CParticleManager(256);
  delete m_pSpringManager;
  m_pSpringManager = new CSpringManager(256);
  m_pCurrentBody = NULL;
  m_pCurrentBody2 = NULL;
} //clear

void CObjectWorld::draw(){
  m_pParticleManager->draw(); //draw particles
} //draw

/// Move the particles, perform Gauss-Seidel relaxation on the springs, and recompute
/// the spring centers based on the position of the particles that they are connected to.

void CObjectWorld::move(){
  m_pParticleManager->move(); //move particles
  m_pSpringManager->Relax(2); //Gauss-Seidel relaxation.
  m_pSpringManager->move(); //compute spring centers
  if(m_pCurrentBody)m_pCurrentBody->move();
  if(m_pCurrentBody2)m_pCurrentBody2->move();
} //move

void CObjectWorld::DeliverImpulse(){
  const int P1 = 3617;
  const int P2 = 2141;
  int nRand = (g_cTimer.time()*P1)%P2;
  int nRand2 = (nRand*P1)%P2;

  float angle;
  if(m_pCurrentBody){
    angle = 2.0f * D3DX_PI * (float)nRand/P2; 
    m_pCurrentBody->DeliverImpulse(angle, 20.0f); //translation
    angle += nRand&1? D3DX_PI/2.0f: -D3DX_PI/2.0f;
    m_pCurrentBody->ApplyTorque(angle, 4.0f); //rotation
  } //if
  
  if(m_pCurrentBody2){
    angle = 2.0f * D3DX_PI * (float)nRand2/P2;
    m_pCurrentBody2->DeliverImpulse(angle, 25.0f); //translation
    angle += nRand2&1? D3DX_PI/2.0f: -D3DX_PI/2.0f;
    m_pCurrentBody2->ApplyTorque(-angle, 4.0f); //rotation
  } //if
} //DeliverImpulse

/// Create a body.
/// \param b Type of body to be created.

void CObjectWorld::CreateBody(BodyType b){
  if(m_pCurrentBody)delete m_pCurrentBody;
  m_pCurrentBody = new CBody(m_pParticleManager, m_pSpringManager);

  if(m_pCurrentBody2)delete m_pCurrentBody2;
  m_pCurrentBody2 = new CBody(m_pParticleManager, m_pSpringManager);

  switch(g_nCurrentBody){
    case CHAIN2_BODY:
       m_pCurrentBody->MakeChain(2, 75, 0.5f, D3DX_PI/6.0f);
       m_pCurrentBody2->MakeChain(2, 75, 0.01f, D3DX_PI/6.0f);
      break;

    case CHAIN3_BODY:
       m_pCurrentBody->MakeChain(3, 75, 0.5f, D3DX_PI/6.0f);
       m_pCurrentBody2->MakeChain(3, 75, 0.01f, D3DX_PI/6.0f);
      break;

    case CHAIN4_BODY:
       m_pCurrentBody->MakeChain(4, 75, 0.5f, D3DX_PI/6.0f);
       m_pCurrentBody2->MakeChain(4, 75, 0.01f, D3DX_PI/6.0f);
      break;

    case TRIANGLE_BODY:
      m_pCurrentBody->MakeTriangle(75, 0.5f);
      m_pCurrentBody2->MakeTriangle(75, 0.02f);
      break;

    case SQUARE_BODY:
      m_pCurrentBody->MakeSquare(75, 0.5f);
      m_pCurrentBody2->MakeSquare(75, 0.02f);
      break;

    case WHEEL5_BODY:
      m_pCurrentBody->MakeWheel(5, 120, 0.5f);
      m_pCurrentBody2->MakeWheel(5, 120, 0.1f);
      break;

    case WHEEL6_BODY:
      m_pCurrentBody->MakeWheel(6, 120, 0.5f);
      m_pCurrentBody2->MakeWheel(6, 120, 0.1f);
      break;

    case RAGDOLL_BODY:
      m_pCurrentBody->MakeRagdoll();  
      m_pCurrentBody2 = NULL;
      break;
  } //switch

  //make room if there are 2 bodies
  if(m_pCurrentBody2){
    m_pCurrentBody->Teleport(200.0f, 50.0f);
    m_pCurrentBody2->Teleport(-200.0f, -50.0f);
  } //if
} //CreateBody