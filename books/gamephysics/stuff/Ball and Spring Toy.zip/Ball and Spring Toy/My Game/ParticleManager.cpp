/// \file ParticleManager.cpp
/// \brief Code for the particle manager class CParticleManager.

#include "ParticleManager.h"

#include "Particle.h"
#include "Springs.h"
#include "renderworld.h"

extern CRenderWorld g_cRenderWorld;
extern int g_nScreenWidth;

CParticleManager::CParticleManager(int size):CAbstractList(size){
} //constructor

CParticle* CParticleManager::create(SpriteType sprite, D3DXVECTOR2 position){
  CParticle* p = CAbstractList::create();
  if(p){
    p->m_nSpriteType = sprite;
    p->m_vPos = p->m_vOldPos = position;
  } //if
  return p;
} //create

/// Move the game particles.

void CParticleManager::move(){ 
  CParticle* p; //a particle
  for(int i=0; i<m_nSize; i++){ //for each particle slot
    p = m_pList[i]; //handy particle pointer
    if(p)p->move(); //make it move
  } //for
} //move

/// Ask the Render World to draw all of the game particles.

void CParticleManager::draw(){ 
  CParticle* p;
  for(int i=0; i<m_nSize; i++){ //for each particle slot
    p = m_pList[i]; //handy particle pointer
    if(p){ //if there's a particle there
      D3DXVECTOR2 v = p->m_vPos;
      g_cRenderWorld.draw(p->m_nSpriteType, v.x, v.y, 
        p->m_fAngle, p->m_fXScale, p->m_fYScale);
    } //if
  } //for
} //draw