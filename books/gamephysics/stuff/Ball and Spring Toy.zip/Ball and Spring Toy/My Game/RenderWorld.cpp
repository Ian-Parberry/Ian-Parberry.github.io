/// \file renderworld.cpp
/// \brief Code for the render world CRenderWorld.

#include "renderworld.h"

/// Load game images. Gets file list from gamesettings.xml.

void CRenderWorld::LoadImages(){ //load images
  LoadBackground(); 
  
  //Load sprites
  Load(BALL_SPRITE, "ball"); 
  Load(WOODCIRCLE_SPRITE, "woodcircle"); 
  Load(SPRING_SPRITE, "spring"); 
  Load(STICK_SPRITE, "stick"); 
} //LoadImages