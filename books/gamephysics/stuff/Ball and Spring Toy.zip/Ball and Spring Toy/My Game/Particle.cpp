/// \file particle.cpp
/// \brief Code for the particle class CParticle.

#include "Particle.h"

#include "Sound.h"
#include "sndlist.h"

extern int g_nScreenWidth; 
extern int g_nScreenHeight; 
extern CSoundManager* g_pSoundManager; 
extern BodyType g_nCurrentBody;

CParticle::CParticle(SpriteType sprite, D3DXVECTOR2 position){ //constructor
  m_nSpriteType = sprite; 
  m_fAngle = 0.0f; m_fXScale = m_fYScale = 1.0f;
  m_fRadius = 32.0f; // From the image file
  m_vPos = m_vOldPos = position;
} //constructor

CParticle::CParticle(){ //constructor
  m_nSpriteType = INVISIBLE_SPRITE; 
  m_vPos = m_vOldPos = D3DXVECTOR2(0, 0);
  m_fAngle = 0.0f; m_fXScale = m_fYScale = 1.0f;
  m_fRadius = 32.0f; // From the image file
} //constructor

/// Check for collision with an edge.
/// Collision and response for particle hitting an edge of the screen. 
/// Checks for a collision, and does the necessary housework for reflecting
/// a particle if it hits an edge. Function
/// backs off the particle so that it does not appear to overlap the edge.
/// \return TRUE if particle hits an edge.

BOOL CParticle::EdgeCollision(){ 
  BOOL rebound = FALSE; //TRUE if collision with an edge
  const float fRestitution = 0.8f; //how bouncy the edges are 
  D3DXVECTOR2 vDelta = m_vPos - m_vOldPos; //velocity
  const float MINCOLLISIONSPEED = 2.0f;

  float left, right, top, bottom;
  left = bottom = m_fRadius;
  right = g_nScreenWidth - m_fRadius;
  top = g_nScreenHeight - m_fRadius;

  //left and right edges
  if(m_vPos.x < left || m_vPos.x > right){ 
    m_vPos.x = m_vPos.x < left? left: right; 
    vDelta.y = -vDelta.y;
    m_vOldPos = m_vPos + fRestitution * vDelta; 
    rebound = rebound || fabs(vDelta.x) > MINCOLLISIONSPEED;
  } //if

  //top and bottom edges
  if(m_vPos.y < bottom || m_vPos.y > top){ //vertical
    m_vPos.y = m_vPos.y < bottom? bottom: top; 
    vDelta.x = -vDelta.x;
    m_vOldPos = m_vPos + fRestitution * vDelta; 
    rebound = rebound || fabs(vDelta.y) > MINCOLLISIONSPEED;
  } //if

  return rebound;
} //EdgeCollision

/// Move the particle, apply collision and response.

void CParticle::move(){ //move particle using Verlet integration.
  D3DXVECTOR2 vTemp = m_vPos;
  m_vPos += m_vPos - m_vOldPos; 
  m_vOldPos = vTemp;
  m_vPos.y -= 0.2f; //gravity

  if(EdgeCollision()){ //edge collision
    if(g_nCurrentBody == RAGDOLL_BODY)
      g_pSoundManager->play(OW_SOUND);
    else if(m_nSpriteType == BALL_SPRITE)
      g_pSoundManager->play(BOING_SOUND);
    else if(m_nSpriteType == WOODCIRCLE_SPRITE)
      g_pSoundManager->play(THUMP_SOUND);
  } //if
} //move

/// Deliver an impulse to the particle, given the angle and magnitude.
/// \param angle Angle at which the impulse is to be applied.
/// \param magnitude Magnitude of the impulse to apply.

void CParticle::DeliverImpulse(float angle, float magnitude){ 
  m_vOldPos = m_vPos - magnitude * D3DXVECTOR2(cos(angle), sin(angle)); //Verlet again
} //DeliverImpulse