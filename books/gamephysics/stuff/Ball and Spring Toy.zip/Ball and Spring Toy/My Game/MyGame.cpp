/// \file MyGame.cpp  
/// \brief Main file for your game.

/// \mainpage Ball and Spring Toy
/// This code was written by Ian Parberry to accompany his book
/// "Introduction to Game Physics with Box2D", published by CRC Press in 2013.
/// 
/// Having been introduced to the theory of Verlet integration and Gauss-
/// Seidel relaxation in Chapter 2, we now examine code for a Ball and Spring
/// Toy, which lets you play with a body made up of a bunch
/// of balls connected by constraints. The constraints can be either stick-like
/// (with no springiness), or spring-like (with lots of springiness). You can
/// cycle through various types of body and you can apply impulses to them
/// to see how they react. The toy starts with the body in the air, from which
/// position it drops under gravity to rest at the bottom of the screen.
/// 
/// The controls are very basic. The space bar applies an impulse in a
/// random direction, the Enter key restarts with the current body type, and
/// the Back key advances to the next body type. The Escape key, as always,
/// quits.
/// 
/// This is a toy, not a game, because there is no concept of winning or losing.

#include "gamedefines.h"
#include "SndList.h"

#include "RenderWorld.h"
#include "ObjectWorld.h"

BodyType g_nCurrentBody = (BodyType)0; ///< Current body type

//globals
char g_szGameName[256]; ///< Name of this game.

CTimer g_cTimer; ///< The game timer.
CSoundManager* g_pSoundManager; ///< The sound manager.

//Render and Object Worlds
CRenderWorld g_cRenderWorld; ///< The Render World.
CObjectWorld g_cObjectWorld; ///< The Object World.

//prototypes for Windows functions
int DefaultWinMain(HINSTANCE, HINSTANCE, LPSTR, int);
LRESULT CALLBACK DefaultWindowProc(HWND, UINT, WPARAM, LPARAM);

/// Start the game.

void BeginGame(){ 
  g_cTimer.StartLevelTimer(); //starting level now     
  g_cObjectWorld.clear(); //clear old objects
  g_cObjectWorld.CreateBody(g_nCurrentBody);
} //BeginGame

/// Initialize and start the game.

void InitGame(){
  g_cRenderWorld.Initialize(); //bails if it fails
  g_cRenderWorld.LoadImages(); //load images from xml file list
  BeginGame(); //it starts...
} //InitGame

/// Shut down game and release resources.

void EndGame(){
  g_cRenderWorld.End();
  ShowCursor(TRUE);
} //EndGame

/// Render a frame of animation.

void RenderFrame(){
  if(g_cRenderWorld.BeginScene()){ //start up graphics pipeline
    g_cRenderWorld.DrawBackground(); //draw the background
    g_cObjectWorld.draw(); //draw the objects
    g_cRenderWorld.EndScene(); //shut down graphics pipeline
  } //if
} //RenderFrame

/// Process a frame of animation.
/// Called once a frame to animate game objects and take appropriate
/// action if the player has won or lost.

void ProcessFrame(){
  //stuff that gets done on every frame
  g_cTimer.beginframe(); //capture current time
  g_pSoundManager->beginframe(); //no double sounds
  g_cObjectWorld.move(); //move all objects
  RenderFrame(); //render a frame of animation
} //ProcessFrame

/// Keyboard handler.
/// Take the appropriate action when the user mashes a key on the keyboard.
///  \param k Virtual key code for the key pressed
///  \return TRUE if the game is to exit

BOOL KeyboardHandler(WPARAM k){ //keyboard handler
  switch(k){
    case VK_ESCAPE: return TRUE; //quit       
    case VK_RETURN: BeginGame(); break; //start again
    case VK_SPACE: g_cObjectWorld.DeliverImpulse(); break; //bam

    case VK_BACK: //next victim
      g_nCurrentBody = (BodyType)(g_nCurrentBody + 1);
      if(g_nCurrentBody == NUM_BODIES)g_nCurrentBody = (BodyType)0;
      BeginGame(); //start
      break;
  } //switch
  return FALSE;
} //KeyboardHandler

// Windows functions.
// Dont mess with these unless you really know what you're doing.
// I've written default functions in the Engine library to take
// care of the boring details of Windows housekeeping.

/// Window procedure.
/// Handler for messages from the Windows API. Dont mess with these unless you really know what you're doing.
///  \param h window handle
///  \param m message code
///  \param w parameter for message 
///  \param l second parameter for message
///  \return 0 if message is handled

LRESULT CALLBACK WindowProc(HWND h, UINT m, WPARAM w, LPARAM l){
  return DefaultWindowProc(h, m, w, l);
} //WindowProc

/// Winmain.  
/// Main entry point for this application. Dont mess with these unless you really know what you're doing.
///  \param hI handle to the current instance of this application
///  \param hP unused
///  \param lpC unused 
///  \param nCS specifies how the window is to be shown
///  \return TRUE if application terminates correctly

int WINAPI WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR lpC, int nCS){    
  ShowCursor(FALSE);
  return DefaultWinMain(hI, hP, lpC, nCS);
} //WinMain