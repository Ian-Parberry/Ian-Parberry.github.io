/// \file gamedefines.h
/// \brief Game defines.

#pragma once

#include "defines.h"

/// \brief Sprite type. 

enum SpriteType{
  INVISIBLE_SPRITE, BALL_SPRITE, WOODCIRCLE_SPRITE, SPRING_SPRITE, STICK_SPRITE
}; //SpriteType

/// \brief Body type.

enum BodyType{
  CHAIN2_BODY, CHAIN3_BODY, CHAIN4_BODY, TRIANGLE_BODY,
  SQUARE_BODY, WHEEL5_BODY, WHEEL6_BODY,
  RAGDOLL_BODY, 
  NUM_BODIES //must be last
}; //BodyType