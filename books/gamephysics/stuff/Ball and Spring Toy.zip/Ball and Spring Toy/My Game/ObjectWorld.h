/// \file objectworld.h
/// \brief Interface for the object world class CObjectWorld.

#pragma once

#include "ParticleManager.h"
#include "SpringManager.h"
#include "Particle.h"

/// \brief The object world.

class CObjectWorld{
  friend class CBody;
  private:
    CParticleManager* m_pParticleManager; ///< Particle manager.
    CSpringManager* m_pSpringManager; ///< Spring manager.
    CBody* m_pCurrentBody; ///< The first body.
    CBody* m_pCurrentBody2; ///< The second body.

  public:
    CObjectWorld(); //< Constructor.

    void clear(); //< Reset to initial conditions.
    void move(); //< Move everything.
    void draw(); //< Draw everything.
    
    void DeliverImpulse(); ///< Apply impulse to the current bodies.
    void CreateBody(BodyType b); ///< Create a pair of bodies.
}; //CObjectWorld