/// \file contactlistener.cpp
/// \brief Code for my Box2D contact listener.

#include "contactlistener.h"

#include "gamedefines.h"
#include "SndList.h"
#include "objectworld.h"

extern CSoundManager* g_pSoundManager;
extern CObjectWorld g_cObjectWorld;

/// Presolve function. Renders a colored star at each contact point and plays
/// the appropriate sound, depending on what type of objects are contacting.
/// \param contact Pointer to the contact.
/// \param oldManifold Pointer to the old contact manifold as it was before this contact.

void CMyContactListener::PreSolve(b2Contact* contact, const b2Manifold* oldManifold){
  b2WorldManifold worldManifold;
  contact->GetWorldManifold(&worldManifold);
  b2PointState state1[2], state2[2];
  b2GetPointStates(state1, state2, oldManifold, contact->GetManifold());
  for(int i=0; i<2; i++)
    if(state2[i] == b2_addState){
      const b2Body* bodyA = contact->GetFixtureA()->GetBody();
      const b2Body* bodyB = contact->GetFixtureB()->GetBody();
      b2Vec2 wp = worldManifold.points[0];
      b2Vec2 vA = bodyA->GetLinearVelocityFromWorldPoint(wp);
      b2Vec2 vB = bodyB->GetLinearVelocityFromWorldPoint(wp);
      b2Vec2 deltavee = vA - vB;
      float32 speed = b2Dot(deltavee, worldManifold.normal);

      //find out what type of objects are contacting
      CGameObject* objectA = (CGameObject*)bodyA->GetUserData();
      CGameObject* objectB = (CGameObject*)bodyB->GetUserData();
      GameObjectType typeA = UNKNOWN_OBJECT;
      GameObjectType typeB = UNKNOWN_OBJECT;
      if(objectA) typeA = (GameObjectType) objectA->m_nObjectType;
      if(objectB) typeB = (GameObjectType) objectB->m_nObjectType;

      //count object types
      int nBallCount=0, nBookCount=0;
      if(typeA == BALL_OBJECT)nBallCount++;
      if(typeB == BALL_OBJECT)nBallCount++;
      if(typeA == BOOK_OBJECT)nBookCount++;
      if(typeB == BOOK_OBJECT)nBookCount++;
      BOOL bCannonBarrel  =
        typeA == CANNONBARREL_OBJECT ||
        typeB == CANNONBARREL_OBJECT;
      BOOL bCannonPart = ((typeA >= CANNONBARREL_OBJECT) && (typeA <= WHEEL_OBJECT)) ||
        ((typeB >= CANNONBARREL_OBJECT) && (typeB <= WHEEL_OBJECT));

      //decide what kind of star to draw at the contact point
      GameObjectType star = BLUESTAR_OBJECT; //default
      if(nBookCount>0 && nBallCount>0) //book to ball
        star = WHITESTAR_OBJECT;
      else if(nBookCount == 2) //book to book
        star = YELLOWSTAR_OBJECT;
      else if(nBallCount == 2) //ball to ball
        star = MAGENTASTAR_OBJECT;
      else if(bCannonPart) //anything to cannon part
        star = REDSTAR_OBJECT;

      //contact response
      if(speed > 0.5f){ //objects moving fast enough

        //sounds depend on what objects are contacting
        if(nBallCount>0)
          g_pSoundManager->play(THUMP_SOUND);
        if(nBookCount>0)
          g_pSoundManager->play(THUMP2_SOUND);
        if(bCannonBarrel && g_cObjectWorld.m_cCannon.IsDead())
          g_pSoundManager->play(CLANG_SOUND);
        if(bCannonBarrel && nBallCount+nBookCount>0)
          g_pSoundManager->play(CLANG_SOUND);

        //star
        CParticle* pParticle = g_cObjectWorld.create(star, 2000);
        if(pParticle)pParticle->      
          Set(D3DXVECTOR2(PW2RW(wp.x), PW2RW(wp.y)), 500, 1.0f);
      } //if
  } //if
} //PreSolve