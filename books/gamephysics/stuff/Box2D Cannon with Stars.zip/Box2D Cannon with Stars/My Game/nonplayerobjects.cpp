/// \file nonplayerobjects.cpp
/// \brief Code for the creation of nonplayer objects.
///
/// Creating things with a physics engine means a lot of tedious,
/// intricate initialization code. It makes sense to hide it in a file of
/// its own. It's not that it's so difficult, but that there is so much of it.
/// There are so many niggly little details to get right.

#include "gamedefines.h"
#include "Box2D\Box2D.h"
#include "ObjectWorld.h"

extern b2World g_b2dPhysicsWorld;
extern CObjectWorld g_cObjectWorld;

/// Create world edges in Physics World.
/// Place Box2D edge shapes in the Physics World in places that correspond to the
/// top, bottom, right, and left edges of the screen in Render World, and a
/// ledge for the cannon to sit upon. The left and  right edges continue upwards
/// for a distance. There is no top to the world.

void CreateWorldEdges(){
  float w, h;
  g_cObjectWorld.GetWorldSize(w, h);

  //Box2D ground
  b2BodyDef bd;
	b2Body* edge = g_b2dPhysicsWorld.CreateBody(&bd);
  b2EdgeShape shape;
	shape.Set(b2Vec2(0, 0), 
    b2Vec2(RW2PW(w), 0));
	edge->CreateFixture(&shape, 0);

  //ledge
  shape.Set(b2Vec2(0, RW2PW(62)), 
    b2Vec2(RW2PW(w/2), RW2PW(62)));
	edge->CreateFixture(&shape, 0);

  //Box2D left edge of screen
  edge = g_b2dPhysicsWorld.CreateBody(&bd);
  shape.Set(b2Vec2(0, RW2PW(-1000)), b2Vec2(0, RW2PW(1000)));
	edge->CreateFixture(&shape, 0);

  //Box2D right edge of screen
  bd.position.x = RW2PW(w);
  edge = g_b2dPhysicsWorld.CreateBody(&bd);
	edge->CreateFixture(&shape, 0); 
} //CreateWorldEdges

/// Place a book in Physics World and Object World.
/// \param x Horizontal coordinate in Physics World units.
/// \param y  Vertical coordinate in Physics World units.
/// \param fd Book fixture definition.

void PlaceBook(float x, float y, const b2FixtureDef& fd){    
  b2BodyDef bd; //Physics World body definition
	bd.type = b2_dynamicBody;

  //Object World
  CGameObject* pGameObject = g_cObjectWorld.create(BOOK_OBJECT);
  bd.userData = (void*)pGameObject; //tell physics world body about object world body
  bd.position.Set(x, y);

  //Physics World
  b2Body* pBook = g_b2dPhysicsWorld.CreateBody(&bd);
  pGameObject->SetPhysicsBody(pBook); //tell object world body about physics world body
  pBook->CreateFixture(&fd);
} //PlaceBook

/// Create a tower of books at the default location.

void CreateTower(){
  float w, h; //Object World width and height.
  g_cObjectWorld.GetWorldSize(w, h);

  //Box2D book shape and fixture
  b2PolygonShape bookshape;
  bookshape.SetAsBox(RW2PW(27), RW2PW(32));
  b2FixtureDef bookfd;
	bookfd.shape = &bookshape;
	bookfd.density = 1.0f;
	bookfd.restitution = 0.3f;

  b2BodyDef bd;
	bd.type = b2_dynamicBody;

  //build tower
  for(int i=0; i<12; i++){
    float x = RW2PW(0.7f*w), y = RW2PW(32 + 64*i);
    if(i&1) //single block at odd-numbered layers   
      PlaceBook(x + RW2PW(30), y, bookfd);
    else{ //pair of blocks at even-numbered layers
      PlaceBook(x, y, bookfd);
      PlaceBook(x + RW2PW(60), y, bookfd);
    } //else
  } //for
} //CreateTower